using EmployeeMgtSystem.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics;

namespace EmployeeMgtSystem.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly ILogger<EmployeeController> _logger;
        private readonly EmpDbConext _empDbContext;
        public EmployeeController(ILogger<EmployeeController> logger, EmpDbConext empDbContext)
        {
            _logger = logger;
            _empDbContext = empDbContext;
        }

        public IActionResult Index()
        {
            ViewBag.Employees = _empDbContext?.Employees?.Include(p => p.Grade).ThenInclude(x => x.Designation).ToList();
            return View();
        }

        public IActionResult Create(int id)
        {
            ViewBag.Designations = _empDbContext?.Designation?.Where(p => p.IsActive).ToList();
            ViewBag.Grades = _empDbContext?.Grade?.Where(p => p.IsActive).ToList();

            var emp = _empDbContext?.Employees?.Find(id);

            if (emp == null)
            {
                emp = new Employee();
            }
            return View(emp);
        }

        public IActionResult Delete(int id)
        {
            var emp = _empDbContext?.Employees?.Find(id);
            _empDbContext?.Employees?.Remove(emp!);
            _empDbContext?.SaveChanges();

            return RedirectToAction("index");
        }

        [HttpPost]
        public IActionResult Save([FromForm] Employee emp)
        {
            if (emp.Id == 0)
            {
                _empDbContext?.Employees?.Add(emp);
            }
            else
            {
                _empDbContext.Attach(emp);
                _empDbContext.Entry(emp).State = EntityState.Modified;
            }
            _empDbContext?.SaveChanges();
            return RedirectToAction("index");
        }
    }
}
