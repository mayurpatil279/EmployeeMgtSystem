﻿using Microsoft.EntityFrameworkCore;

namespace EmployeeMgtSystem.Models
{
    public class EmpDbConext : DbContext
    {
        public virtual DbSet<Employee> Employees { get; set; }
        public virtual DbSet<Designation>? Designation { get; set; }
        public virtual DbSet<Grade>? Grade { get; set; }

        public EmpDbConext(DbContextOptions<EmpDbConext> options) : base(options) { }
    }
}
