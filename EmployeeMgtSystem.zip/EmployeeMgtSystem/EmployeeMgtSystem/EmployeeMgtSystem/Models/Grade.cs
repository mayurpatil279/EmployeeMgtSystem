﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EmployeeMgtSystem.Models
{
    public class Grade
    {
        [Key]
        public int Id { get; set; }
        public string? Name { get; set; }
        public int DesignationId { get; set; }
        public bool IsActive { get; set; }

        [ForeignKey("DesignationId")]
        public virtual Designation? Designation { get; set; }
    }
}
