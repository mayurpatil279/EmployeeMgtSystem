﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EmployeeMgtSystem.Models
{
    public class Employee
    {
        [Key]
        public int Id { get; set; }
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? EmailAddress { get; set; }
        public string? PhoneNumber { get; set; }
        public int DesignationId { get; set; }
        public int GradeId { get; set; }

        //[ForeignKey("DesignationId")]
        //public virtual Designation? Designation { get; set; }

        [ForeignKey("GradeId")]
        public virtual Grade? Grade { get; set; }
    }
}
